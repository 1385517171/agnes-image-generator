# Qoder Install And Customize

## Recommended install paths

- User level: `~/.qoder/skills/bearer-token-image-generator/`
- Project level: `<project>/.qoder/skills/bearer-token-image-generator/`

After placing the folder, restart Qoder if the skill does not appear immediately.

## Minimal required customization

Edit `scripts/generic_image_generate.py` and replace:

- `PROVIDER_NAME`
- `MODEL_NAME`
- `API_URL`
- `PRIMARY_ENV_KEY`
- `SECONDARY_ENV_KEY`

## Optional customization

- Update `.env.example` to match the final env key names
- Update `scripts/setup_bearer_env.py` defaults if you want different key names
- Rename the folder and change `name:` in `SKILL.md` if you want a provider-specific skill

## Example provider mapping

```python
PROVIDER_NAME = "Agnes"
MODEL_NAME = "agnes-image-2.1-flash"
API_URL = "https://apihub.agnes-ai.com/v1/images/generations"
PRIMARY_ENV_KEY = "AGNES_API_KEY"
SECONDARY_ENV_KEY = "AGNES_IMAGE_API_KEY"
```

## One-time token setup

```bash
python3 "<skill_root>/scripts/setup_bearer_env.py" --api-key "Bearer YOUR_TOKEN"
```

## First test run

```bash
python3 "<skill_root>/scripts/generic_image_generate.py" \
  --prompt "A cinematic mountain landscape at sunrise" \
  --size 1024x1024 \
  --output /tmp/qoder-image-test.png
```
