---
name: "bearer-token-image-generator"
description: "Generates images through bearer-token image APIs with reusable helper scripts. Use when users need a portable Qoder skill for text-to-image or image-to-image workflows."
---

# Bearer Token Image Generator

Use this skill when the user wants a reusable image-generation workflow in Qoder and the provider exposes an OpenAI-style image API authenticated by a bearer token.

## What this bundle contains

- `scripts/generic_image_generate.py`: generic runtime for text-to-image and image-to-image by URL
- `scripts/setup_bearer_env.py`: one-time bearer-token setup helper
- `.env.example`: sample env key file
- `references/install-and-customize.md`: Qoder installation and customization notes

## Before first use

Customize these constants in `scripts/generic_image_generate.py`:

- `PROVIDER_NAME`
- `MODEL_NAME`
- `API_URL`
- `PRIMARY_ENV_KEY`
- `SECONDARY_ENV_KEY`

If needed, also update `.env.example` and the default env key names in `scripts/setup_bearer_env.py`.

## When to use this skill

Invoke this skill when the user:

- asks for a reusable Qoder image-generation skill
- wants to call a bearer-token image API from Qoder
- needs a generic template for text-to-image or image-to-image workflows
- wants one-time token setup plus later repeated calls

## Execution rules

1. If the provider details are still placeholders, tell the user to customize the constants before running the skill.
2. If the user has not provided a prompt, ask for one.
3. If the task is image-to-image and there is no source image URL, ask for the URL.
4. Prefer saving the first result to a local file when the user wants a deliverable image file.
5. Report the effective prompt, size, returned image URL, and local output path if downloaded.

## Locate the skill root

This skill may be installed in either of these locations:

- project level: `.qoder/skills/bearer-token-image-generator`
- user level: `~/.qoder/skills/bearer-token-image-generator`

Before running scripts, determine which path exists and use its absolute path as the skill root.

## One-time token setup

Run:

```bash
python3 "<skill_root>/scripts/setup_bearer_env.py" --api-key "Bearer YOUR_TOKEN"
```

The setup helper accepts either:

- `Bearer <token>`
- raw token text

By default it saves the token to `.env.local` inside the installed skill folder, so later calls can reuse it without re-entering the key.

## Generate an image

Text-to-image:

```bash
python3 "<skill_root>/scripts/generic_image_generate.py" \
  --prompt "your prompt" \
  --size 1024x1024 \
  --output /tmp/generated-image.png
```

Image-to-image by URL:

```bash
python3 "<skill_root>/scripts/generic_image_generate.py" \
  --prompt "restyle the source image" \
  --size 1024x1024 \
  --image-url "https://example.com/source.png" \
  --output /tmp/restyled-image.png
```

## Auth behavior

- loads `.env.local` and `.env` from the skill folder
- also ignores masked placeholder secrets such as `***`
- prefers a real key over empty or redacted values
- accepts `--api-key` to override saved configuration

## Output contract

The runtime script prints JSON with:

- `provider`
- `model`
- `size`
- `image_url`
- `output_path`
- `raw_response`

Qoder or other agents can parse this JSON for downstream steps.
