---
name: "agnes-video-generator"
description: "Generates videos with Agnes-Video-V2.0. Use when users ask for text-to-video, image-to-video, multi-image video, or keyframe animation through Agnes."
---

# Agnes Video Generator

Use this skill when the user wants to generate videos with **Agnes-Video-V2.0**.

This package is authored as a portable **AgentSkills-style** skill so it can be reused across Codex, Claude Code, OpenClaw, Trae, Hermes, and similar agent frameworks.

## What this skill does

- creates async video generation tasks with `POST https://apihub.agnes-ai.com/v1/videos`
- retrieves task results with `GET https://apihub.agnes-ai.com/v1/videos/{task_id}`
- supports text-to-video, image-to-video, multi-image video, and keyframe animation
- optionally polls until completion and downloads the final video file

## When to invoke

Invoke this skill when the user:

- asks to generate a video with Agnes-Video-V2.0
- wants text-to-video generation from a prompt
- wants to animate one input image into a video
- wants multi-image or keyframe-based video generation
- wants a reusable Agnes video workflow for a coding agent

## Skill root rules

Before running any script, determine the absolute path of this skill folder.

- In frameworks that support `{baseDir}`, use it as the skill root.
- Otherwise resolve the installed skill directory path first and substitute that absolute path into commands.

## Required setup

Provide the API key in one of these ways:

- environment variable `AGNES_API_KEY`
- environment variable `AGNES_VIDEO_API_KEY`
- CLI argument `--api-key`

Recommended one-time setup:

```bash
python3 <skill_root>/scripts/setup_agnes_video_env.py --api-key "Bearer YOUR_TOKEN"
```

The setup script accepts both a raw token and a full `Bearer <token>` string.

For generic bundles it writes to `.env.local`. Under Hermes, it writes to `HERMES_HOME/.env` because skill directories may be read-only.

## Execution

Primary script:

```bash
python3 <skill_root>/scripts/agnes_video_generate.py --help
```

### Text-to-video example

```bash
python3 <skill_root>/scripts/agnes_video_generate.py   --prompt "A cinematic shot of a cat walking on the beach at sunset, soft ocean waves, warm golden lighting, realistic motion"   --width 1152   --height 768   --num-frames 121   --frame-rate 24   --output /tmp/agnes-video.mp4
```

### Image-to-video example

```bash
python3 <skill_root>/scripts/agnes_video_generate.py   --prompt "The woman slowly turns around and looks back at the camera, natural facial expression, cinematic camera movement"   --image-url "https://example.com/image.png"   --num-frames 121   --frame-rate 24   --output /tmp/agnes-image-to-video.mp4
```

### Keyframe example

```bash
python3 <skill_root>/scripts/agnes_video_generate.py   --prompt "Generate a smooth cinematic transition between the keyframes, maintaining visual consistency and natural camera movement"   --image-url "https://example.com/keyframe1.png"   --image-url "https://example.com/keyframe2.png"   --mode keyframes   --num-frames 121   --frame-rate 24   --output /tmp/agnes-keyframes.mp4
```

### Retrieve an existing task

```bash
python3 <skill_root>/scripts/agnes_video_generate.py --task-id task_123456
```

## Working rules

1. If the user has not provided a prompt for a new task, ask for one.
2. If the task is image-to-video and no input image URL is available, ask for the image URL.
3. If the task is keyframe or multi-image generation, collect all reference image URLs first.
4. `num_frames` must be less than or equal to `441` and satisfy `8n + 1`.
5. Prefer polling until completion unless the user explicitly wants task submission only.
6. If the user wants a local deliverable, pass `--output` to download the finished video.
7. After execution, report the prompt, task ID, status, progress, video URL, and local output path if downloaded.

## Output contract

The script prints JSON with:

- `task_id`
- `status`
- `progress`
- `video_url`
- `size`
- `seconds`
- `output_path`
- `raw_response`

## Supporting files

- `scripts/agnes_video_generate.py`: runtime entrypoint
- `scripts/setup_agnes_video_env.py`: token bootstrap helper
- `references/framework-installation.md`: per-framework install paths
- `references/runtime-notes.md`: provider behavior, polling, and constraints
