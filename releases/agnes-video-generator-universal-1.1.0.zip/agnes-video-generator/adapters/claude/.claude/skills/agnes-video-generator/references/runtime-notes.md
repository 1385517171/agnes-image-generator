# Runtime Notes

## Provider behavior

- Model: `agnes-video-v2.0`
- Create task: `POST https://apihub.agnes-ai.com/v1/videos`
- Retrieve task: `GET https://apihub.agnes-ai.com/v1/videos/{task_id}`
- Auth: `Authorization: Bearer <token>`

## Supported flows

- text-to-video
- image-to-video
- multi-image video
- keyframe animation

## Polling behavior

By default the runtime script submits a task and polls until the task reaches `completed` or `failed`.

Use `--no-wait` if you only want the initial task submission and task ID.

## Validation rules

- `num_frames` must be `<= 441`
- `num_frames` must satisfy `8n + 1`
- `frame_rate` must be between `1` and `60`
- `keyframes` mode requires at least two image URLs

## Secret handling

- real keys override masked placeholders such as `***`
- `.env.local`, `.env`, and `HERMES_HOME/.env` are loaded
- the setup helper writes both `AGNES_API_KEY` and `AGNES_VIDEO_API_KEY`
