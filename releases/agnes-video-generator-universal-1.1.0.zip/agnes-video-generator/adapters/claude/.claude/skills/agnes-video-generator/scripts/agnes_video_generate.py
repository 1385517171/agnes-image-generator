#!/usr/bin/env python3
import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

CREATE_TASK_URL = "https://apihub.agnes-ai.com/v1/videos"
GET_TASK_URL_TEMPLATE = "https://apihub.agnes-ai.com/v1/videos/{task_id}"
MODEL_NAME = "agnes-video-v2.0"
DEFAULT_TIMEOUT = 180
DEFAULT_WIDTH = 1152
DEFAULT_HEIGHT = 768
DEFAULT_NUM_FRAMES = 121
DEFAULT_FRAME_RATE = 24
DEFAULT_POLL_INTERVAL = 10
DEFAULT_MAX_WAIT_SECONDS = 1800
ENV_FILES = (".env.local", ".env")
HERMES_HOME = Path(os.getenv("HERMES_HOME", "~/.hermes")).expanduser()
HERMES_ENV = HERMES_HOME / ".env"
MASKED_SECRET_MARKERS = {"***", "<redacted>", "[redacted]", "redacted"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate videos with Agnes-Video-V2.0.")
    parser.add_argument("--prompt", help="Prompt for video generation.")
    parser.add_argument("--task-id", help="Existing Agnes video task ID to query.")
    parser.add_argument(
        "--image-url",
        action="append",
        default=[],
        help="Optional image URL input. Pass multiple times for multi-image or keyframe mode.",
    )
    parser.add_argument(
        "--mode",
        choices=("ti2vid", "keyframes"),
        help="Optional generation mode. Use keyframes for keyframe animation.",
    )
    parser.add_argument("--width", type=int, default=DEFAULT_WIDTH, help="Video width. Default: 1152.")
    parser.add_argument("--height", type=int, default=DEFAULT_HEIGHT, help="Video height. Default: 768.")
    parser.add_argument(
        "--num-frames",
        type=int,
        default=DEFAULT_NUM_FRAMES,
        help="Frame count. Must be <= 441 and satisfy 8n + 1.",
    )
    parser.add_argument(
        "--num-inference-steps",
        type=int,
        help="Optional number of inference steps.",
    )
    parser.add_argument("--seed", type=int, help="Optional random seed.")
    parser.add_argument(
        "--frame-rate",
        type=float,
        default=DEFAULT_FRAME_RATE,
        help="Video FPS. Supported range: 1-60.",
    )
    parser.add_argument("--negative-prompt", help="Optional negative prompt.")
    parser.add_argument("--output", help="Optional file path to download the completed video.")
    parser.add_argument(
        "--api-key",
        help="Agnes API key. Defaults to AGNES_API_KEY or AGNES_VIDEO_API_KEY.",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=DEFAULT_TIMEOUT,
        help="HTTP request timeout in seconds.",
    )
    parser.add_argument(
        "--poll-interval",
        type=int,
        default=DEFAULT_POLL_INTERVAL,
        help="Polling interval in seconds while waiting for completion.",
    )
    parser.add_argument(
        "--max-wait-seconds",
        type=int,
        default=DEFAULT_MAX_WAIT_SECONDS,
        help="Maximum wait time in seconds when polling for completion.",
    )
    parser.add_argument(
        "--no-wait",
        action="store_true",
        help="Submit the task and return immediately without polling.",
    )
    args = parser.parse_args()
    validate_args(args)
    return args


def validate_args(args: argparse.Namespace) -> None:
    if args.task_id:
        if args.prompt:
            raise SystemExit("Use either --task-id to query a task or --prompt to create a new task, not both.")
        return
    if not args.prompt:
        raise SystemExit("Missing prompt. Pass --prompt for a new task or --task-id to query an existing task.")
    if args.num_frames > 441 or args.num_frames < 1 or (args.num_frames - 1) % 8 != 0:
        raise SystemExit("num_frames must be <= 441 and satisfy 8n + 1, such as 81, 121, 161, 241, or 441.")
    if not (1 <= args.frame_rate <= 60):
        raise SystemExit("frame_rate must be between 1 and 60.")
    if args.mode == "keyframes" and len(args.image_url) < 2:
        raise SystemExit("keyframes mode requires at least two --image-url values.")


def normalize_api_key(value: str) -> str:
    token = value.strip()
    if token.lower().startswith("bearer "):
        token = token[7:].strip()
    return token


def is_usable_api_key(value: str | None) -> bool:
    if value is None:
        return False
    token = normalize_api_key(value)
    if not token:
        return False
    return token.lower() not in MASKED_SECRET_MARKERS


def _load_env_file(env_path: Path) -> None:
    if not env_path.exists():
        return
    for raw_line in env_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'\"")
        current_value = os.environ.get(key)
        if key and (key not in os.environ or (not is_usable_api_key(current_value) and is_usable_api_key(value))):
            os.environ[key] = value


def load_env_files() -> None:
    script_root = Path(__file__).resolve().parent.parent
    for file_name in ENV_FILES:
        _load_env_file(script_root / file_name)
    _load_env_file(HERMES_ENV)


def resolve_api_key(cli_value: str | None) -> str:
    candidates = (cli_value, os.getenv("AGNES_API_KEY"), os.getenv("AGNES_VIDEO_API_KEY"))
    for candidate in candidates:
        if is_usable_api_key(candidate):
            return normalize_api_key(candidate)
    raise SystemExit("Missing valid API key. Pass --api-key or set AGNES_API_KEY / AGNES_VIDEO_API_KEY.")


def build_payload(args: argparse.Namespace) -> dict:
    payload = {
        "model": MODEL_NAME,
        "prompt": args.prompt,
        "width": args.width,
        "height": args.height,
        "num_frames": args.num_frames,
        "frame_rate": args.frame_rate,
    }
    if args.num_inference_steps is not None:
        payload["num_inference_steps"] = args.num_inference_steps
    if args.seed is not None:
        payload["seed"] = args.seed
    if args.negative_prompt:
        payload["negative_prompt"] = args.negative_prompt
    if len(args.image_url) == 1:
        payload["image"] = args.image_url[0]
        if args.mode:
            payload["mode"] = args.mode
    elif len(args.image_url) > 1:
        payload["extra_body"] = {"image": args.image_url}
        if args.mode:
            payload["extra_body"]["mode"] = args.mode
    return payload


def request_json(url: str, method: str, api_key: str, timeout: int, payload: dict | None = None) -> dict:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method=method,
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        error_body = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Agnes API request failed with HTTP {exc.code}: {error_body}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Agnes API request failed: {exc}") from exc


def create_task(args: argparse.Namespace, api_key: str) -> dict:
    return request_json(CREATE_TASK_URL, "POST", api_key, args.timeout, build_payload(args))


def get_task(task_id: str, api_key: str, timeout: int) -> dict:
    url = GET_TASK_URL_TEMPLATE.format(task_id=urllib.parse.quote(task_id, safe=""))
    return request_json(url, "GET", api_key, timeout)


def wait_for_completion(task_id: str, api_key: str, timeout: int, poll_interval: int, max_wait_seconds: int) -> dict:
    deadline = time.time() + max_wait_seconds
    last_result = None
    while True:
        last_result = get_task(task_id, api_key, timeout)
        status = last_result.get("status")
        if status in {"completed", "failed"}:
            return last_result
        if time.time() >= deadline:
            raise SystemExit(f"Timed out waiting for task {task_id}. Last known status: {status}")
        time.sleep(max(1, poll_interval))


def extract_video_url(result: dict) -> str | None:
    video_url = result.get("video_url")
    if isinstance(video_url, str) and video_url:
        return video_url
    if isinstance(result.get("url"), str):
        return result["url"]
    data = result.get("data")
    if isinstance(data, list) and data:
        first = data[0]
        if isinstance(first, dict):
            return first.get("video_url") or first.get("url")
    return None


def download_file(url: str, output_path: str, timeout: int) -> None:
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        with urllib.request.urlopen(url, timeout=timeout) as response:
            target.write_bytes(response.read())
    except urllib.error.URLError as exc:
        raise SystemExit(f"Failed to download generated video: {exc}") from exc


def summarize(result: dict, output_path: str | None = None) -> dict:
    return {
        "task_id": result.get("id"),
        "model": result.get("model", MODEL_NAME),
        "status": result.get("status"),
        "progress": result.get("progress"),
        "video_url": extract_video_url(result),
        "size": result.get("size"),
        "seconds": result.get("seconds"),
        "output_path": output_path,
        "raw_response": result,
    }


def main() -> int:
    args = parse_args()
    load_env_files()
    api_key = resolve_api_key(args.api_key)

    if args.task_id:
        result = get_task(args.task_id, api_key, args.timeout)
    else:
        created = create_task(args, api_key)
        if args.no_wait:
            print(json.dumps(summarize(created), ensure_ascii=True, indent=2))
            return 0
        task_id = created.get("id")
        if not isinstance(task_id, str) or not task_id:
            raise SystemExit(f"Task creation succeeded but no task id was returned: {json.dumps(created, ensure_ascii=True)}")
        result = wait_for_completion(
            task_id,
            api_key,
            args.timeout,
            args.poll_interval,
            args.max_wait_seconds,
        )

    video_url = extract_video_url(result)
    output_path = None
    if args.output:
        if result.get("status") != "completed" or not video_url:
            raise SystemExit("No completed video URL found in Agnes response; cannot download.")
        output_path = str(Path(args.output).resolve())
        download_file(video_url, output_path, args.timeout)

    print(json.dumps(summarize(result, output_path), ensure_ascii=True, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
