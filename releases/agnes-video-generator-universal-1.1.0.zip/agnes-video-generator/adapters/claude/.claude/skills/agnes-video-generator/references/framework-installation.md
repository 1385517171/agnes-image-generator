# Framework Installation

## Universal rule

The root folder of this bundle is already a valid AgentSkills-style skill directory.

If a framework accepts a skill folder containing `SKILL.md`, install the root folder directly.

## Codex

Codex reads skills from `.agents/skills/<skill-name>/` inside a repo, or `~/.agents/skills/<skill-name>/` for personal skills.

Recommended install paths:

- project: `.agents/skills/agnes-video-generator/`
- personal: `~/.agents/skills/agnes-video-generator/`

## Claude Code

Claude Code reads skills from `.claude/skills/<skill-name>/` or `~/.claude/skills/<skill-name>/`.

Recommended install paths:

- project: `.claude/skills/agnes-video-generator/`
- personal: `~/.claude/skills/agnes-video-generator/`

## OpenClaw

OpenClaw uses AgentSkills-compatible skill folders and loads them from:

- `<workspace>/skills/agnes-video-generator/`
- `<workspace>/.agents/skills/agnes-video-generator/`
- `~/.agents/skills/agnes-video-generator/`
- `~/.openclaw/skills/agnes-video-generator/`

If your OpenClaw setup prefers a workspace-local install, use `<workspace>/skills/agnes-video-generator/`.

## Trae

Trae expects `.trae/skills/<skill-name>/SKILL.md` in the workspace. Use the ready-made adapter in:

- `adapters/trae/.trae/skills/agnes-video-generator/SKILL.md`

Copy the `.trae/` directory from the adapter into your workspace root, and keep the package `scripts/` directory alongside it.

## Hermes

For Hermes-compatible environments, install the full folder under:

- `~/.hermes/skills/agnes-video-generator/`

Then run:

```bash
python3 ~/.hermes/skills/agnes-video-generator/scripts/setup_agnes_video_env.py --api-key "Bearer YOUR_TOKEN"
```

Under Hermes, the setup helper automatically prefers `HERMES_HOME/.env` for credential persistence.
