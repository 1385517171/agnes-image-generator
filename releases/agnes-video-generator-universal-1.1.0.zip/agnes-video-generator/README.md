# Agnes Video Generator Universal Bundle

Portable **AgentSkills-compatible** Agnes-Video-V2.0 package for multiple agent frameworks.

## What this bundle targets

- Codex
- Claude Code
- OpenClaw
- Trae
- Hermes-compatible agents
- Any agent framework that can read `SKILL.md` and execute local Python scripts

## Package layout

- `SKILL.md`: universal entrypoint for AgentSkills-compatible frameworks
- `scripts/`: reusable CLI implementation
- `references/`: install notes and runtime notes
- `adapters/`: framework-specific install-ready directory layouts
- `manifest.json`: package metadata
- `.env.example`: env template

## Why this is cross-framework

The common denominator across modern agent frameworks is the AgentSkills-style skill folder:

- a skill directory
- a `SKILL.md` file with YAML frontmatter
- optional `scripts/`, `references/`, and assets

This bundle keeps that standard form at the root, then adds install-ready adapter directories for frameworks that prefer different on-disk paths.

## Quick start

1. Install the root skill folder into your target framework's skill path.
2. Run once:

```bash
python3 <skill_root>/scripts/setup_agnes_video_env.py --api-key "Bearer YOUR_TOKEN"
```

3. Generate a video:

```bash
python3 <skill_root>/scripts/agnes_video_generate.py   --prompt "A cinematic shot of a cat walking on the beach at sunset"   --width 1152   --height 768   --num-frames 121   --frame-rate 24   --output /tmp/agnes-video.mp4
```

## Install guides

See `references/framework-installation.md` for Codex, Claude Code, OpenClaw, Trae, and Hermes paths.
